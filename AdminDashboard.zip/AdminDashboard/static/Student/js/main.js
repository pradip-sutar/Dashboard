function showFileName1(input) {
    var cls1 = input.files[0].name;
    document.getElementById('cls1').innerText = cls1;
  }

  function showFileName2(input) {
    var cls2 = input.files[0].name;
    document.getElementById('cls2').innerText = cls2;
  }
  
  function showFileName3(input) {
    var pg = input.files[0].name;
    document.getElementById('pg').innerText = pg;
  }
  
  function showFileName4(input) {
    var exp = input.files[0].name;
    document.getElementById('exp').innerText = exp;
  }
  
  function showFileName5(input) {
    var adhaar = input.files[0].name;
    document.getElementById('adhaar').innerText = adhaar;
  }
  
  function showFileName6(input) {
    var pan = input.files[0].name;
    document.getElementById('pan').innerText = pan;
  }
  